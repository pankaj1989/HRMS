# HRMS Functional Specification

> Comprehensive functional specification for an Indian-compliance-first HRMS platform.
> Multi-entity, multi-tenant SaaS. White-collar primary, blue-collar fully supported.
> Built on Next.js 15 + Express/TypeScript + MongoDB + BullMQ + GraphQL.

---

## Document conventions

This spec is organized as a folder of markdown files, one concern per file, navigable in any text editor, IDE, or via GitHub/GitLab rendering. Mermaid diagrams render in GitHub, Obsidian, VS Code (with extension), and most modern markdown viewers.

### Tag legend

Throughout the spec, the following inline tags appear:

| Tag | Meaning |
|---|---|
| `[VERIFY]` | A specific number, format, or rule that I am not 100% certain about. Must be confirmed against primary source (EPFO circular, Income Tax notification, NSDL RPU manual, state government PT slab notification) before code is written. |
| `[ASSUMPTION]` | A product / business decision I have made on your behalf because the strategy doc didn't specify. You must accept, reject, or refine. |
| `[DECISION]` | A point where two reasonable approaches exist and I picked one with a stated rationale. |
| `[v1]` `[v2]` `[v3]` | Scoping marker. v1 = Months 0–9, v2 = Months 10–18, v3 = Months 19–30. Untagged items are v1 by default. |
| `[BLUE-COLLAR]` | Specific to factory / retail / field workforce — different rules, formats, or workflows. |
| `[WHITE-COLLAR]` | Specific to office / IT / services workforce. |
| `[CA-REVIEW]` | Statutory interpretation that should be confirmed by a Chartered Accountant or labor lawyer before going live. |
| `[OPEN]` | Open question that needs business decision from you. |

### Statutory references

All statutory rules in this spec reference Indian law as of April 2026:
- Income Tax Act, 1961 (and Income Tax Act, 2025, effective April 1, 2026 for FY 2026–27)
- Employees' Provident Funds & Miscellaneous Provisions Act, 1952
- Employees' State Insurance Act, 1948
- Payment of Gratuity Act, 1972
- Payment of Bonus Act, 1965
- Payment of Wages Act, 1936
- Code on Wages, 2019
- Industrial Relations Code, 2020
- Code on Social Security, 2020
- Occupational Safety, Health and Working Conditions Code, 2020
- Maternity Benefit Act, 1961 (as amended 2017)
- Contract Labour (Regulation and Abolition) Act, 1970
- Factories Act, 1948
- Shops & Establishments Acts (state-specific)
- State Professional Tax Acts
- State Labour Welfare Fund Acts

The four Labour Codes (Wage, IR, SS, OSH) consolidated 29 central labour laws and were notified in November 2025. Some provisions are in force, some require state-level rules to be operational. Where the spec touches code-vs-old-act differences, I flag explicitly.

### Schema notation

Schemas are written as TypeScript interfaces with MongoDB-friendly types:

```typescript
interface Example {
  _id: ObjectId;                    // MongoDB primary key
  tenantId: ObjectId;               // multi-tenant isolation
  entityId: ObjectId;               // multi-entity isolation
  // ... domain fields
  createdAt: Date;
  updatedAt: Date;
  createdBy: ObjectId;              // user who created
  updatedBy: ObjectId;
  version: number;                  // optimistic concurrency
  isDeleted: boolean;               // soft delete
}
```

Common types:
- `ObjectId` — MongoDB ObjectId
- `Decimal128` — for monetary values; never use `number` for money
- `ISODate` — date as ISO 8601 string when serialized
- `Money` — `{ amount: Decimal128, currency: 'INR' }`

### Money handling rule

**All monetary values are stored as paise (integer) or Decimal128 with explicit currency.** Never as JavaScript `number`. Floating-point math on currency leads to ₹0.01 errors that break PF reconciliation and statutory filings. Display layer converts to rupees with two decimals. This is a hard rule throughout the spec.

---

## Table of contents

### Phase 1 — Foundations & Employee (this delivery)

#### `/00-foundations/`

1. [00-overview.md](./00-foundations/00-overview.md) — Architectural philosophy, design principles, what this spec covers
2. [01-multi-tenancy.md](./00-foundations/01-multi-tenancy.md) — Tenant isolation, data residency, query enforcement
3. [02-multi-entity.md](./00-foundations/02-multi-entity.md) — Legal entity model, statutory registration handling
4. [03-identity-and-rbac.md](./00-foundations/03-identity-and-rbac.md) — Users, roles, permissions, field-level security
5. [04-audit-and-compliance-hooks.md](./00-foundations/04-audit-and-compliance-hooks.md) — Audit log, change tracking, evidence pipeline
6. [05-data-model-conventions.md](./00-foundations/05-data-model-conventions.md) — Schema patterns, time-versioning, soft deletes
7. [06-statutory-rules-engine.md](./00-foundations/06-statutory-rules-engine.md) — Versioned compliance rules architecture
8. [07-glossary.md](./00-foundations/07-glossary.md) — Every acronym used in this spec, defined

#### `/01-employee/`

1. [00-overview.md](./01-employee/00-overview.md) — Employee module purpose, scope, integration points
2. [01-employee-master-schema.md](./01-employee/01-employee-master-schema.md) — The Employee record, all fields, indexes
3. [02-employment-record.md](./01-employee/02-employment-record.md) — Employment history, designations, transfers
4. [03-compensation-record.md](./01-employee/03-compensation-record.md) — CTC structure, revisions, retros
5. [04-statutory-ids.md](./01-employee/04-statutory-ids.md) — PAN, Aadhaar, UAN, ESI#, etc. — encryption and validation
6. [05-documents-and-kyc.md](./01-employee/05-documents-and-kyc.md) — Document collection, BGV, e-sign integration
7. [06-lifecycle-state-machine.md](./01-employee/06-lifecycle-state-machine.md) — Hire to retire, every transition, every workflow
8. [07-edge-cases.md](./01-employee/07-edge-cases.md) — 30+ edge cases with handling specs
9. [08-white-vs-blue-collar-differences.md](./01-employee/08-white-vs-blue-collar-differences.md) — Field-by-field differences

### Phase 2 — Attendance & Leave (next session)

#### `/02-attendance/` (planned)

- 00-overview, 01-attendance-capture, 02-shifts-and-rosters, 03-leave-types-and-policies,
  04-leave-accrual-engine, 05-overtime-engine, 06-regularization-workflow, 07-statutory-attendance-registers,
  08-edge-cases, 09-blue-collar-shift-patterns, 10-mobile-and-offline

### Phase 3 — Payroll & Compliance (next session)

#### `/03-payroll/` (planned)

- 00-overview, 01-salary-structure-builder, 02-component-library,
  03-payroll-period-and-cycle, 04-pre-payroll-inputs, 05-payroll-engine,
  06-arrears-and-retros, 07-bonus-calculation, 08-gratuity-calculation,
  09-fnf-settlement, 10-payslip-format, 11-bank-file-formats,
  12-journal-voucher-and-accounting, 13-edge-cases

#### `/04-compliance/` (planned)

- 00-overview, 01-pf-act-and-formulas, 02-esi-act-and-formulas,
  03-tds-and-income-tax, 04-professional-tax-state-wise, 05-lwf-state-wise,
  06-bonus-act, 07-gratuity-act, 08-maternity-benefit-act,
  09-clra-contract-labour, 10-factories-act, 11-shops-and-establishments,
  12-statutory-registers, 13-statutory-files-and-formats,
  14-2026-labour-codes, 15-statutory-deadlines-calendar

### Phase 4 — Talent & Performance & ESS (later session)

#### `/05-recruitment/`, `/06-performance/`, `/07-ess-mobile/` (planned)

### Phase 5 — Workflow, Analytics, Appendix (later session)

#### `/08-workflow/`, `/09-analytics/`, `/99-appendix/` (planned)

---

## How to read this spec

For sprint planning, read in this order:
1. `/00-foundations/` cover-to-cover (architectural decisions)
2. `/01-employee/` cover-to-cover (the foundational entity)
3. Then go module by module based on sprint priority

For implementation, each module file has:
- **Purpose** section — what it does and why
- **Data model** section — schemas with indexes
- **Behavior** section — formulas, state machines, workflows
- **Edge cases** section — what can go wrong
- **Outputs** section — files, reports, integrations
- **Open questions** section — things you must decide

For Claude Code, point it at the relevant module folder and the foundations folder. Each module is self-contained enough that an agent can implement it without re-reading the entire spec.

---

## Versioning of this spec

This is a living document. Convention:
- Major version bumps when statutory law changes (e.g., 2026 Labour Codes notifications)
- Minor version bumps when product scope changes
- Patch bumps for typos, clarifications, edge case additions

Current version: **0.1.0** (Phase 1 draft, April 2026)
